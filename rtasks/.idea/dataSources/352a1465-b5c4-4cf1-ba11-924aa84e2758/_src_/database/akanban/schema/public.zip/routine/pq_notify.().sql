CREATE FUNCTION pq_notify () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 begin
  perform pg_notify(new.q_name, '');
  return null;
end 
$$
